# -*- coding: utf-8 -*-
TSIPlayer_VERSION="2023.03.19.0"
