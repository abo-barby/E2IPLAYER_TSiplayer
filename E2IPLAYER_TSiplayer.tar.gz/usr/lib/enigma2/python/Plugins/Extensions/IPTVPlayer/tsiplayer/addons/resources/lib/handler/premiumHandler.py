# -*- coding: utf-8 -*-
class cPremiumHandler(object):
    def __init__(self, *args):
        pass
        
    def isPremiumModeAvailable(self):
        return False