# -*- coding: utf-8 -*-
# https://github.com/Kodi-vStream/venom-xbmc-addons
# Venom.

# sLibrary = xbmc.translatePath('special://home/addons/plugin.video.vstream').decode('utf-8')
# sys.path.append (sLibrary)

class cAbout:
    def checkdownload(self):
        return